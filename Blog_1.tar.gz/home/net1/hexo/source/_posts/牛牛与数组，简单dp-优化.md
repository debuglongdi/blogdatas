---
title: 牛牛与数组，简单dp+优化
date: 2019-11-29 18:02:43
tags:
 - acm
 - 原创
categories: ACM
---
## 题目描述：

```
牛牛喜欢这样的数组：
1：长度为n
2：每一个数都在1到k之间
3：对于任意连续的两个数A，B，A<=B 与（A % B != 0） 两个条件至少成立一个
请问一共有多少满足条件的数组，对1e9+7取模
```
## 输入描述：
```
输入两个整数n,k
1 ≤ n ≤ 10
1 ≤ k ≤ 100000
```
# 样例：
```
输入:
      2  2
输出:
      3
```
## 分析：
   很明显，这题需要用dp来做，其状态转移方程：
   
```
dp[i][j]=dp[i-1][q](q<=j||q%j!=0) 其中（1<=q<=k）
```
开始时我写的错误代码：

```cpp
#include<iostream>
#include<cstring>
using namespace std;
int dp[11][100001];
const int mod = 1000000007;
int main() {
	int i, j, q;
	int n, k;
	while (cin >> n >> k) {
		memset(dp, 0, sizeof(dp));
		for (i = 1; i <= k; i++) dp[1][i] = 1;
		for (i = 1; i <= n; i++) {
			for (j = 1; j <= k; j++) {
				for (q = 1; q <= k; q++) {
					if ((q <= j) || (q % j != 0))
						dp[i][j] = (dp[i][j] + dp[i - 1][q]) % mod;
				}
			}
		}
		int res = 0;
		for (i = 1; i <= k; i++) {
			res = (res + dp[n][i]) % mod;
		}
		cout << res << endl;
	}
	return 0;
}
```

该方法时间复杂度) O(n*k^2)会超时，所以要进行优化，考虑到dp[i][j]=dp[i-1][q] (q<=j||q%j!=0)
可以使dp[i][j]=dp[i-1][q]-dp[i-1][x] (q(1-k),x(x是j的倍数))；
则代码如下：

```cpp
#include<iostream>
#include<vector>
#include<cstdio>
#include<cstring> 
using namespace std;
typedef long long ll;
const int MOD = 1e9 + 7;
const int max_n = 1e5 + 2;
vector<int >vec[max_n];
int dp[11][max_n];
int main() {
	int n, k;
	int i, j, q;
	while (cin >> n >> k) {
		//初始化
		ll ans = 0;
		ll temp = 0;
		for (i = 1; i <= k; i++) {
			for (j = 2; i * j <= k; j++) {
				vec[i].push_back(i * j);//生成i的倍数； 
			}
		}
		memset(dp, 0, sizeof(dp));
		for (i = 1; i <=k; i++) dp[1][i] = 1;
		//计算
		for (i = 2; i <= n; i++) {
			ans = 0;
			for (j = 1; j <= k; j++) ans = (ans + dp[i - 1][j]);//预处理ans=dp[i-1][j](1<=j<=k);
			for (j = 1; j <= k; j++) {
				temp = 0;
				for (q = 0; q < vec[j].size(); q++) {
					temp = (temp + dp[i - 1][vec[j][q]]);//将计算dp[i][j]时多加的部分存在temp=dp[i-1][q](q是j的倍数) 
				}                                        //此时不满足(q<=j||q%j!=0); 
				dp[i][j] = (ans  - temp) % MOD;//dp[i][j]=dp[i-1][x]当且仅当(j<=x||j%x!=0),NB; 
			}                                       //故dp[i][j]=(ans-tmep)%MOD; 
		}
		ll res = 0;
		for (i = 1; i <= k; i++) res = (dp[n][i] + res) % MOD;
		cout << res << endl;
		for (j = 1; j <= k; j++) vec[j].clear();//不要忘记clear,不然空间会超限； 
	}
	return 0;
}
```
此时我们可以看到：时间复杂度变成了O(n * k * sqrt (k) );
